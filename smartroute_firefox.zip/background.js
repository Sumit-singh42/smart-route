// Create Context Menu Logic
chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
        id: "smartroute-analyze",
        title: "Analyze with SmartRoute AI",
        contexts: ["selection"]
    });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === "smartroute-analyze" && info.selectionText) {

        // We can't open the popup programmatically, but we can send a notification
        // Or store it in storage for the popup to read next time open.
        // For MVP: Let's fetch in background and alert result (or usage logs).

        // Better UX: Send to backend -> Show notification
        const query = info.selectionText;

        fetch('http://localhost:8000/v1/chat/completions', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                messages: [{ role: 'user', content: `Summarize this concisely: ${query}` }],
                model: 'semiflash'
            })
        })
            .then(res => res.json())
            .then(data => {
                const result = data.choices[0].message.content;

                // Inject a content script to show alert/modal? 
                // Keep it simple: Chrome Notification (requires permissions) or just console log.
                // Let's execute script to alert user on page.
                chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    func: (text) => alert(`SmartRoute Analysis:\n\n${text}`),
                    args: [result]
                });
            })
            .catch(err => console.error(err));
    }
});
