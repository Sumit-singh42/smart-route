document.addEventListener('DOMContentLoaded', () => {
    const promptInput = document.getElementById('prompt-input');
    const submitBtn = document.getElementById('submit-btn');
    const resultContainer = document.getElementById('result-container');
    const resultText = document.getElementById('result-text');
    const modelBadge = document.getElementById('model-badge');
    const latencyDisplay = document.getElementById('latency-display');
    const btnText = document.getElementById('btn-text');
    const loader = document.getElementById('loader');

    // Auto-focus input
    promptInput.focus();

    submitBtn.addEventListener('click', async () => {
        const prompt = promptInput.value.trim();
        if (!prompt) return;

        // UI Loading State
        setLoading(true);
        resultContainer.classList.add('hidden');
        resultText.innerText = '';

        try {
            const start = Date.now();

            // Call Local Backend
            const res = await fetch('http://127.0.0.1:8000/v1/chat/completions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    messages: [{ role: 'user', content: prompt }],
                    model: 'gpt-4o' // Routing logic handles the actual model
                })
            });

            const data = await res.json();
            const duration = Date.now() - start;

            if (data.error) throw new Error(data.error);

            // Render Result
            const content = data.choices[0].message.content;
            const model = data.model;

            resultText.innerText = content;
            modelBadge.innerText = `Routed to: ${model}`;
            latencyDisplay.innerText = `${duration}ms`;

            // Color Logic for Badges
            if (model.includes('gpt-4')) modelBadge.style.color = '#c084fc'; // Purple
            else if (model.includes('mythomax')) modelBadge.style.color = '#818cf8'; // Indigo
            else modelBadge.style.color = '#22c55e'; // Green (Groq)

            resultContainer.classList.remove('hidden');

        } catch (err) {
            resultText.innerText = `Error: ${err.message}. Is the backend running at localhost:8000?`;
            resultContainer.classList.remove('hidden');
        } finally {
            setLoading(false);
        }
    });

    function setLoading(isLoading) {
        submitBtn.disabled = isLoading;
        if (isLoading) {
            btnText.classList.add('hidden');
            loader.classList.remove('hidden');
        } else {
            btnText.classList.remove('hidden');
            loader.classList.add('hidden');
        }
    }
});
